# Algorithm implementation based on the OceanProtocol ecosystem

Copy the full `python` directory and implement the algorithm in the `src/implementation/` subdirectory, if needed import other files using relative routes.

_Algorithm details_